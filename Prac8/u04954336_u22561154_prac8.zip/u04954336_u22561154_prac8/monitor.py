import os
import hashlib
import socket
import time
import logging

# Configure logging
logging.basicConfig(filename='monitoring.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def monitor_file(file_path, server_file_path, ftp_host, ftp_port, ftp_user, ftp_pass):
    # Get the initial hash of the file
    initial_hash = hash_file(file_path)

    while True:
        # Check if the file exists
        if not os.path.exists(file_path):
            logging.info(f"File '{file_path}' does not exist. Downloading from server.")
            download_file(ftp_host, ftp_port, ftp_user, ftp_pass, server_file_path, file_path)
            initial_hash = hash_file(file_path)
        else:
            # Check if the file has been modified
            current_hash = hash_file(file_path)
            if current_hash != initial_hash:
                logging.info(f"File '{file_path}' has been modified. Downloading from server.")
                download_file(ftp_host, ftp_port, ftp_user, ftp_pass, server_file_path, file_path)
                initial_hash = current_hash
        
        time.sleep(60)  # Poll every minute

def hash_file(file_path):
    # Compute the hash of the file
    hasher = hashlib.md5()
    try:
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                hasher.update(chunk)
    except FileNotFoundError:
        logging.error(f"File '{file_path}' not found during hashing.")
        return None
    return hasher.hexdigest()

def send_ftp_command(ftp_socket, command):
    # Send an FTP command and get the response
    ftp_socket.sendall(f"{command}\r\n".encode())
    response = ftp_socket.recv(4096).decode()
    logging.info(f"Sent command: {command}")
    logging.info(f"Received response: {response}")
    return response

def download_file(ftp_host, ftp_port, ftp_user, ftp_pass, server_file_path, local_file_path):
    try:
        # Connect to the FTP server
        ftp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ftp_socket.connect((ftp_host, ftp_port))
        ftp_socket.recv(4096)  # Receive the initial server response
        
        # Log in to the FTP server
        send_ftp_command(ftp_socket, f"USER {ftp_user}")
        send_ftp_command(ftp_socket, f"PASS {ftp_pass}")
        
        # Switch to binary mode
        send_ftp_command(ftp_socket, "TYPE I")
        
        # Enter passive mode
        pasv_response = send_ftp_command(ftp_socket, "PASV")
        start_idx = pasv_response.find('(') + 1
        end_idx = pasv_response.find(')')
        pasv_info = pasv_response[start_idx:end_idx].split(',')
        pasv_ip = '.'.join(pasv_info[:4])
        pasv_port = (int(pasv_info[4]) << 8) + int(pasv_info[5])
        
        # Connect to the data port
        data_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        data_socket.connect((pasv_ip, pasv_port))
        
        # Send the RETR command to retrieve the file
        send_ftp_command(ftp_socket, f"RETR {server_file_path}")
        
        # Download the file
        with open(local_file_path, 'wb') as f:
            while True:
                data = data_socket.recv(4096)
                if not data:
                    break
                f.write(data)
        
        # Close the data connection
        data_socket.close()
        ftp_socket.recv(4096)  # Receive transfer complete message
        send_ftp_command(ftp_socket, "QUIT")
        
        # Close the control connection
        ftp_socket.close()
        logging.info(f"Downloaded '{server_file_path}' from FTP server.")
    except Exception as e:
        logging.error(f"Failed to download '{server_file_path}' from FTP server: {str(e)}")

if __name__ == "__main__":
    # File paths and FTP credentials
    monitored_file = "file.txt"
    server_file = "ftp/files/file.txt"
    ftp_host = "127.0.0.1"
    ftp_port = 21
    ftp_user = "yirou"
    ftp_pass = "MSGBSL9082"

    # Start monitoring the file
    monitor_file(monitored_file, server_file, ftp_host, ftp_port, ftp_user, ftp_pass)


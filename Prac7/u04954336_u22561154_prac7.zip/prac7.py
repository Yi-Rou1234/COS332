#!/usr/bin/python3
# Written by Lloyd Creighton u04954336 and Yi-Rou (Monica) Hung u22561154

import socket

def check_bcc(email_content, your_email):
    
    # Check if your email is the recipient
    to_header = get_original_to_header(email_content)
    if to_header:
        parts = to_header.split(':')
        parts = parts[1].strip().split(',')            
        if your_email in parts:
            return False  # You are the recipient, not a BCC recipient
    
    # Check if your email is in the CC header
    cc_header = get_original_cc_header(email_content)
    if cc_header:
        cc_recipients = cc_header.split(':')
        cc_recipients = cc_recipients[1].strip().split(',')
        if your_email in cc_recipients:
            return False  # You are in the CC header, not a BCC recipient

    return True  # If not in To or CC, you are a BCC recipient

def get_original_to_header(email_content):
    # Split the email content into lines
    lines = email_content.split('\n')
    
    # Find the to header line
    for line in lines:
        if line.lower().startswith('to:'):
            return line.strip()

    return None  # to header not found

def get_original_cc_header(email_content):
    # Split the email content into lines
    lines = email_content.split('\n')
    
    # Find the cc header line
    for line in lines:
        if line.lower().startswith('cc:'):
            return line.strip()

    return None  # cc header not found

def get_message_id(email_content):
    # Split the email content into lines
    lines = email_content.split('\n')
    
    # Find the message id
    for line in lines:
        if line.lower().startswith('message-id:'):
            return line.strip()

    return None  # message id not found

# Connect to the POP3 server
server = 'localhost'
port = 110
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((server, port))

# Receive the server's welcome message
print(sock.recv(1024).decode())

# Send the user's credentials
username = 'lloyd'
password = 'testpassword'
sock.send(f'USER {username}\r\n'.encode())
print(sock.recv(1024).decode())
sock.send(f'PASS {password}\r\n'.encode())
print(sock.recv(1024).decode())

# List emails
sock.send(b'LIST\r\n')
emails = sock.recv(1024).decode().split('\n')[1:-2]
for email in emails:
    email_number, _ = email.strip().split()
    # Retrieve headers for the email
    sock.send(f'TOP {email_number} 0\r\n'.encode())
    email_headers = sock.recv(1024).decode()
    email_headers_safe = email_headers
    print(email_headers)
    #Find the message ID
    message_id = get_message_id(email_headers)
    message_id = message_id.split(':')
    message_id = message_id[1].strip()
    print(f'Message ID: {message_id}')
    
    #Check if message ID is contained in checkedmails.txt
    with open('checkedmails.txt', 'r') as f:
        checked_mails = f.read().split('\n')
        if message_id in checked_mails:
            print(f'Email {email_number} has already been checked')
            toCheck = False
            continue
    
    #Check if email subject contains the string [BCC Warning]
    toCheck = True
    
    subjectCheck = email_headers.split('\n')
    for i, header in enumerate(subjectCheck):
        if header.lower().startswith('subject:'):
            header_parts = header.split(':')
            print(header_parts[1].strip())
            if header_parts[1].strip().startswith('[BCC Warning]'):
                print(f'Email {email_number} has already been checked')
                toCheck = False
                continue
            break
    
    #Append message ID to checkedmails.txt
    with open('checkedmails.txt', 'a') as f:
        f.write(f'{message_id}\n')
    
    
    if(toCheck and check_bcc(email_headers, f'lloyd@localhost.com')):
        #Split email headers into lines
        email_headers = email_headers.split('\n')
        #Find the subject line, assign to subject variable
        for i, header in enumerate(email_headers):
            if header.lower().startswith('subject:'):
                header_parts = header.split(':')
                header_parts[1] = '[BCC Warning] ' + header_parts[1].strip()
                subject = header_parts[1]
                break
        #Construct the original "to" header
        original_to = get_original_to_header(email_headers_safe)
        #Construct the original "cc" header
        original_cc = get_original_cc_header(email_headers_safe)
        
        
        print(f'Email {email_number} is a BCC email')
        #Open socket to smtp server and send warning email with the same header
        smtp_server = 'localhost'
        smtp_port = 25
        smtp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        smtp_sock.connect((smtp_server, smtp_port))
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(b'HELO localhost\r\n')
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(b'MAIL FROM: admin@localhost.com\r\n')
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(b'RCPT TO: lloyd@localhost.com\r\n')
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(b'DATA\r\n')
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(f"Subject: {subject}\r\n".encode())
        smtp_sock.send(f'To: {original_to}\r\n'.encode())
        if(original_cc):
            smtp_sock.send(f'cc: {original_cc}\r\n'.encode())
        smtp_sock.send(b'\r\n')
        smtp_sock.send(b'This email was sent to you as a BCC recipient.\r\n')
        smtp_sock.send(b'\r\n.\r\n')
        print(smtp_sock.recv(1024).decode())
        smtp_sock.send(b'QUIT\r\n')

# Close the connection
sock.send(b'QUIT\r\n')
sock.close()